import React, { useEffect, useState } from "react";
import ReactApexChart from "react-apexcharts";
import _ from "lodash";
import { IChart } from "interface/IChart";
interface ISeries {
  name: string;
  type: string;
  data: number[];
}

interface Iprops {
  chart: IChart[];
}

const ChartStrategy = ({ chart }: Iprops) => {
  // console.log("chart", chart);

  const [series, setSeries] = useState<ISeries[]>([
    {
      name: "LP_staking_rewards",
      type: "column",
      data: [],
    },
    {
      name: "early_withdrawal_fees",
      type: "column",
      data: [],
    },
    {
      name: "lion_staking_rewards",
      type: "column",
      data: [],
    },
    {
      name: "price_appreciation_lion",
      type: "column",
      data: [],
    },
    {
      name: "price_appreciation_shares",
      type: "column",
      data: [],
    },
    {
      name: "share_staking_rewards",
      type: "column",
      data: [],
    },
    {
      name: "ROI",
      type: "line",
      data: [],
    },
  ]);

  useEffect(() => {
    if (!_.isEmpty(chart)) {
      let _series: ISeries[] = series;
      chart.forEach((item: IChart) => {
        // const {strategey} = item;
        _series[0].data.push(item.LP_staking_rewards);
        _series[1].data.push(item.early_withdrawal_fees);
        _series[2].data.push(item.lion_staking_rewards);
        _series[3].data.push(item.price_appreciation_lion);
        _series[4].data.push(item.price_appreciation_shares);
        _series[5].data.push(item.share_staking_rewards);
        _series[6].data.push(item.ROI);
        // console.log("_series", _series);
      });

      setSeries(_series);
    }
  }, [series, chart]);

  // console.log("series", series);
  const series1 = [
    {
      name: "LP_staking_rewards",
      type: "column",
      data: [44, 55, 41, 67, 22, 43],
    },
    {
      name: "early_withdrawal_fees",
      type: "column",
      data: [13, 23, 20, 8, 13, 27],
    },
    {
      name: "lion_staking_rewards",
      type: "column",
      data: [11, 17, 15, 15, 21, 14],
    },
    {
      name: "price_appreciation_lion",
      type: "column",
      data: [21, 7, 25, 13, 22, 8],
    },
    {
      name: "price_appreciation_shares",
      type: "column",
      data: [21, 7, 25, 13, 22, 8],
    },
    {
      name: "share_staking_rewards",
      type: "column",
      data: [21, 7, 25, 13, 22, 8],
    },
    {
      name: "ROI",
      type: "line",
      data: [23, 42, 35, 27, 43, 22],
    },
  ];
  // console.log("series1", series1);
  const options = {
    // chart: {
    //   id: "apexchart-example",
    // },
    // xaxis: {
    //   categories: [1991, 1992, 1993, 1994, 1995, 1996, 1997, 1998, 1999],
    // },
    chart: {
      id: "basic-bar",
      // type: "bar",
      height: 350,
      stacked: true,
      // toolbar: {
      //   show: true,
      // },
      // zoom: {
      //   enabled: true,
      // },
    },

    // responsive: [
    //   {
    //     breakpoint: 480,
    //     options: {
    //       legend: {
    //         position: "bottom",
    //         offsetX: -10,
    //         offsetY: 0,
    //       },
    //     },
    //   },
    // ],
    plotOptions: {
      bar: {
        horizontal: false,
        borderRadius: 10,
      },
    },
    xaxis: {
      // type: "datetime",
      categories: [
        "Stake Lion",
        "Stake shares",
        "Stake p1",
        "Stake p3",
        "Lock p1",
        "Lock p3",
      ],
    },
    yaxis: {
      title: {
        text: "ROI(%)",
      },
    },
    // legend: {
    //   position: "right",
    //   offsetY: 40,
    // },
    fill: {
      opacity: 1,
    },
  };

  return (
    <ReactApexChart
      options={options}
      series={series}
      type="line"
      height={400}
    />
  );
};

export default ChartStrategy;

// const domContainer = document.querySelector("#app");
// ReactDOM.render(React.createElement(ApexChart), domContainer);

// import React, { useEffect, useState } from "react";
// import { ResponsiveBar } from "@nivo/bar";

// const ChartStrategyBar = (data: any) => {
//   console.log("data", data.data);
//   return (
//     <ResponsiveBar
//       data={data.data}
//       keys={[
//         "price_appreciation_lion",
//         "price_appreciation_shares",
//         "lion_staking_rewards",
//         "share_staking_rewards",
//         "LP_staking_rewards",
//         "early_withdrawal_fees",
//       ]}
//       indexBy="strategy"
//       margin={{ top: 50, right: 200, bottom: 50, left: 60 }}
//       padding={0.3}
//       valueScale={{ type: "linear" }}
//       indexScale={{ type: "band", round: true }}
//       colors={{ scheme: "nivo" }}
//       defs={[
//         {
//           id: "dots",
//           type: "patternDots",
//           background: "inherit",
//           color: "#38bcb2",
//           size: 4,
//           padding: 1,
//           stagger: true,
//         },
//         {
//           id: "lines",
//           type: "patternLines",
//           background: "inherit",
//           color: "#eed312",
//           rotation: -45,
//           lineWidth: 6,
//           spacing: 10,
//         },
//       ]}
//       fill={[
//         {
//           match: {
//             id: "fries",
//           },
//           id: "dots",
//         },
//         {
//           match: {
//             id: "sandwich",
//           },
//           id: "lines",
//         },
//       ]}
//       borderColor={{
//         from: "color",
//         modifiers: [["darker", 1.6]],
//       }}
//       axisTop={null}
//       axisRight={null}
//       axisBottom={{
//         tickSize: 5,
//         tickPadding: 5,
//         tickRotation: 0,
//         legend: "Strategy",
//         legendPosition: "middle",
//         legendOffset: 32,
//       }}
//       axisLeft={{
//         tickSize: 5,
//         tickPadding: 5,
//         tickRotation: 0,
//         legend: "ROI (%)",
//         legendPosition: "middle",
//         legendOffset: -40,
//       }}
//       labelSkipWidth={12}
//       labelSkipHeight={12}
//       labelTextColor={{
//         from: "color",
//         modifiers: [["darker", 1.6]],
//       }}
//       legends={[
//         {
//           dataFrom: "keys",
//           anchor: "bottom-right",
//           direction: "column",
//           justify: false,
//           translateX: 120,
//           translateY: 0,
//           itemsSpacing: 2,
//           itemWidth: 100,
//           itemHeight: 20,
//           itemDirection: "left-to-right",
//           itemOpacity: 0.85,
//           symbolSize: 20,
//           effects: [
//             {
//               on: "hover",
//               style: {
//                 itemOpacity: 1,
//               },
//             },
//           ],
//         },
//       ]}
//       role="application"
//       ariaLabel="Lion ROI"
//       barAriaLabel={function (e) {
//         return e.id + ": " + e.formattedValue + " in country: " + e.indexValue;
//       }}
//     />
//   );
// };

// export const ChartStrategy = (data: any) => {
//   return (
//     <div style={{ height: "400px" }}>
//       <ChartStrategyBar data={data.data} />
//     </div>
//   );
// };
