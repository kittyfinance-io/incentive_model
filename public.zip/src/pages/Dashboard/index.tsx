import React, { useEffect, useState } from "react";

import { Box, Grid, Typography } from "@mui/material";
import { EnvInputs, get_roi, ProtocolParams } from "reward";
import { __debounce } from "utils/debounce";
import { IProtocol } from "interface/IProtocol";
import { IEnvInputs } from "interface/IEnvInputs";
import InputSlider from "components/InputSlider";
import { MaxInput, MinInput, StepInput, UnitInput } from "config/ChartInput";
import ChartStrategy from "components/Chart";
import { IChart } from "interface/IChart";

const Dashboard = () => {
  const [investAmount, setInvestAmount] = React.useState<number>(1000);
  const pre_launch_avax_kitty = 20450;
  // Protocol Params
  const [stateProtocolParams, setStateProtocolParams] = useState<IProtocol>({
    protocol_tax: 0.05,
    peg_tax_re_mint_rate: 0.9,
    protocol_tax_public_vs_dao_ratio: 0.2,
    supply_expansion_rate: 0.9,
    marketing_cut: 0.11,
    team_cut: 0.3125,
    early_withdrawal_tax: 0.5,
    p1_vs_p3_supply_expansion: 0.8,
    p1_vs_l1_reward_ratio: 0.1,
    p3_vs_l3_reward_ratio: 0.1,
    reemission_timeframe: 30, // ** Invest Time
  });
  // Env Inputs

  const [stateEnvInputs, setStateEnvInputs] = useState<IEnvInputs>({
    avax_price_in_dollar: 17.22,
    lion_price_in_dollar: 30, // ** Lion Price
    // share_price_in_dollar: 5500, // 110000 / (100 * protocolParams.protocol_tax_public_vs_dao_ratio)

    buying_volume: 500000,
    selling_volume: 250000,

    p1_liq_in_dollar: (pre_launch_avax_kitty / 4) * 2 * 30,
    p1_pol_ratio: 0.1,
    p3_liq_in_dollar: (pre_launch_avax_kitty / 4) * 2 * 30,

    lion_staking_pool_size_in_tokens: pre_launch_avax_kitty / 2,
    p1_staked_in_dollar: (pre_launch_avax_kitty / 8) * 2 * 30,
    p3_staked_in_dollar: (pre_launch_avax_kitty / 8) * 2 * 30,
    p1_locked_in_dollar: (pre_launch_avax_kitty / 8) * 2 * 30,
    p3_locked_in_dollar: (pre_launch_avax_kitty / 8) * 2 * 30,

    pending_liq_contrib_rewards: 0,
    timeframe: 30, // in days
    early_withdrawal_rate: 0.5,
  });

  const [ROISum, setROISum] = useState([]);
  const [chart, setChart] = useState<IChart[]>([]);

  useEffect(() => {
    __debounce(
      () => {
        const protocolParams = new ProtocolParams(
          stateProtocolParams.protocol_tax, // protocol tax
          stateProtocolParams.peg_tax_re_mint_rate, // peg tax remint rate
          stateProtocolParams.protocol_tax_public_vs_dao_ratio, // protocol tax to public
          stateProtocolParams.supply_expansion_rate, // supply expansion rate -> the lower this is, the faster the theoretical price of LionAvax rises & the lower the LP staking APR

          stateProtocolParams.marketing_cut, // marketing cut
          stateProtocolParams.team_cut, // team cut

          stateProtocolParams.early_withdrawal_tax, // early withdrawal tax
          stateProtocolParams.p1_vs_p3_supply_expansion, // p1 vs p3 supply expansion
          stateProtocolParams.p1_vs_l1_reward_ratio, // p1 vs l1 reward ratio
          stateProtocolParams.p3_vs_l3_reward_ratio, // p3 vs l3 reward ratio,
          stateProtocolParams.reemission_timeframe // reemission timeframe of burned peg contributions in days
        );

        const envInputs = new EnvInputs(
          stateEnvInputs.avax_price_in_dollar, // avax price
          stateEnvInputs.lion_price_in_dollar, // lion avax price
          110000 / (100 * protocolParams.protocol_tax_public_vs_dao_ratio), // lion share price
          stateEnvInputs.buying_volume, // buying vol
          stateEnvInputs.selling_volume, // selling vol

          stateEnvInputs.p1_liq_in_dollar, // p1 liquidity
          stateEnvInputs.p1_pol_ratio, // pol ratio p1
          stateEnvInputs.p3_liq_in_dollar, // p3 liq on avax (assuming 80% of the 10% community shares are staked bc they get rewards too), x2 for other side of pool, /2 for 2 chains on launch

          stateEnvInputs.lion_staking_pool_size_in_tokens, // lion staking tokens, assuming 5k in p1, 5k in p3

          stateEnvInputs.p1_staked_in_dollar,
          stateEnvInputs.p3_staked_in_dollar,
          stateEnvInputs.p1_locked_in_dollar,
          stateEnvInputs.p3_locked_in_dollar,

          stateEnvInputs.pending_liq_contrib_rewards, // pending liq contribution rewards
          stateEnvInputs.timeframe, // timeframe in days
          stateEnvInputs.early_withdrawal_rate // early withdrawal rate of P1 and P3 stakers
        );

        let _chart: IChart[] = [];

        let roi_sum: any = [{}];
        let index = 0;
        protocolParams.modes.forEach((item) => {
          const getRoi: any = get_roi(
            investAmount,
            envInputs,
            protocolParams,
            item
          );
          const roi = getRoi!["roi"];
          console.log("roi", roi);

          // console.log(
          //   `\n=====> ROI from investing ${investAmount}$ into >${item}<: ${
          //     roi * 100
          //   }% in ${envInputs.timeframe} days ===== \n`
          // );

          let res: IChart = {
            strategy: item,
            ROI: Number(roi.toFixed(2)),
            price_appreciation_lion: Number(
              (getRoi.price_appreciation_lion / investAmount).toFixed(2)
            ),
            price_appreciation_shares: Number(
              (getRoi.price_appreciation_shares / investAmount).toFixed(2)
            ),
            lion_staking_rewards: Number(
              (getRoi.lion_staking_rewards / investAmount).toFixed(2)
            ),
            share_staking_rewards: Number(
              (getRoi.share_staking_rewards / investAmount).toFixed(2)
            ),
            LP_staking_rewards: Number(
              (getRoi.LP_staking_rewards / investAmount).toFixed(2)
            ),
            early_withdrawal_fees: Number(
              (getRoi.early_withdrawal_fees / investAmount).toFixed(2)
            ),
          };
          roi_sum = [...roi_sum];
          roi_sum[0][item] = Number(roi.toFixed(2));

          _chart = [..._chart, res];
        });
        setROISum(roi_sum);
        setChart(_chart);
      },
      1000,
      "Calculate ROI"
    );
  }, [
    investAmount,
    pre_launch_avax_kitty,
    stateEnvInputs,
    stateProtocolParams,
  ]);

  return (
    <>
      <Box sx={{ px: 5 }}>
        {/* <ChartStrategy data={chart} /> */}
        <ChartStrategy chart={chart} />
        <Grid container columnSpacing={5} marginTop={5}>
          <Grid item xs={12} md={4}>
            <Typography
              variant="h4"
              color="red"
              paddingY={3}
              textAlign="center"
            >
              Protocol Params
            </Typography>

            {Object.keys(stateProtocolParams).map((item, index) => (
              <InputSlider
                name={item}
                value={stateProtocolParams[item as keyof IProtocol]}
                maxValue={MaxInput[item as keyof IProtocol]}
                minValue={MinInput[item as keyof IProtocol]}
                stepValue={StepInput[item as keyof IProtocol]}
                unitValue={UnitInput[item as keyof IProtocol]}
                setValue={(value) =>
                  setStateProtocolParams({
                    ...stateProtocolParams,
                    [item as keyof IProtocol]: value,
                  })
                }
              />
            ))}
          </Grid>
          <Grid item xs={12} md={8}>
            <Typography
              variant="h4"
              color="red"
              paddingY={3}
              textAlign="center"
            >
              Env Inputs
            </Typography>

            <Grid container columnSpacing={5}>
              <Grid item xs={12} md={6}>
                <InputSlider
                  name="Invest Money"
                  value={investAmount}
                  maxValue={10000}
                  unitValue={"$"}
                  setValue={(value) => setInvestAmount(value)}
                />
              </Grid>
              {/* <Grid item xs={12} md={6}>
                <InputSlider
                  name="Pre Launch AVAX-Kitty"
                  value={pre_launch_avax_kitty}
                  maxValue={100000}
                  setValue={(value) => setPre_launch_avax_kitty(value)}
                />
              </Grid> */}
              {Object.keys(stateEnvInputs).map((item, index) => (
                <Grid item xs={12} md={6}>
                  <InputSlider
                    name={item}
                    value={stateEnvInputs[item as keyof IEnvInputs]}
                    maxValue={MaxInput[item as keyof IEnvInputs]}
                    minValue={MinInput[item as keyof IProtocol]}
                    stepValue={StepInput[item as keyof IProtocol]}
                    unitValue={UnitInput[item as keyof IProtocol]}
                    setValue={(value) =>
                      setStateEnvInputs({
                        ...stateEnvInputs,
                        [item as keyof IProtocol]: value,
                      })
                    }
                  />
                </Grid>
              ))}
            </Grid>
          </Grid>
        </Grid>
      </Box>
    </>
  );
};

export default Dashboard;
