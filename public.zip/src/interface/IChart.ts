export interface IChart {
  strategy: string;
  ROI: number;
  price_appreciation_lion: number;
  price_appreciation_shares: number;
  lion_staking_rewards: number;
  share_staking_rewards: number;
  LP_staking_rewards: number;
  early_withdrawal_fees: number;
}
